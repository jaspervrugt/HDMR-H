Hi Lexi:

Does it work now for attached file? Made some more updates for you. What I write next is unrelated to the error you got very important for publication:
 
Thus far we are using the model to generate the Y matrix with N simulations. Hence,  size of  Y(1:N,1:n,1:K). N simulations that each consist of n values each (evolution of species count at n different times) and for K = 4 species.  

Point is that model is chaotic and hence this really complicates sensitivity calculation at each of the n times. Instead, what should we do?

We compute instead one or more statistics from each of the N simulations. For example (didactic purpose), lets say we compute the standard deviation of the counts of each simulation. This is one value; if we store this value for each species we now get Y(1:N,1:4) - that is, each parameter vector has a simulated standard deviation for each species. We can now see which parameters are most sensitive to the standard deviation - in other words which parameters in the model most determine the std of the simulated record. 

If we use ecologically relevant statistics/metric (std is not rooted in ecological theory - it is just a statistics number) then this analysis tells us which metrics/transformations we should use to light up the information for each model parameter. This is very interesting and a paper in a top journal by itself. So we should try a bunch of different metrics - we compute those from Y and then analyze with HDMR.

Jasper   

